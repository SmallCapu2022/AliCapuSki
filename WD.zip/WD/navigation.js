function connectUser() {
    var pseudo = document.getElementById("pseudo").value;
    var password = document.getElementById("password").value;

    console.log("pseudo : "+pseudo+" password : " +password);
    if(pseudo == "alicia" && password =="0000"){
        location.assign("connected.html?pseudo="+pseudo);
    } else {
        alert("Mauvais pseudo/ Mot de passe");
    }
}

function retrievePseudo(){
    console.log(document.location.search);
    let parameters = new URLSearchParams(document.location.search);
    let pseudo = parameters.get("pseudo");
    console.log(pseudo);

    let p = document.getElementById("pseudo");
    p.innerHTML = pseudo;
}