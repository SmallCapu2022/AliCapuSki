<?php
if(!isset($_GET["plat"]) || empty($_GET["plat"])) {
    http_response_code(400);
    die();
}
// on va récupérer le plat passé en get
    $plat = json_decode($_GET["plat"]);
?>
<html>
    <head>
        <title><?php echo $plat->name_fr ?></title>
    </head>
    <body>
        <img src=<?php $plat->images[0] ?>/>
        <h1><?php echo $plat->name_fr; ?></h1>
        <?php
            foreach($plat->ingredients as $ingredient) {
                echo $ingredient->name_fr." ";
            }
        ?>
    </body>
</html>
