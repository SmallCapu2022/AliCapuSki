<html>
    <head>
        <title>Mon restaurant</title>
    </head>
    <body>
        <?php
           $url = "http://test.api.catering.bluecodegames.com/menu";

           // Création d'un flux
           $opts = array(
                'http'=>array(
                'method'=>"POST",
                'header'=>"Content-Type:application/json",
                'content' => '{"id_shop":1}'
                )
            );

            $context = stream_context_create($opts);

            $file = file_get_contents($url, false, $context);
            $json = json_decode($file);

            $data = $json->data;
            
            foreach($data as $category){
                echo "<h1>".$category->name_fr."</h1>";
                foreach($category->items as $item) {
                    echo "<a href='detail.php?plat='>".$item->name_fr." ".$item->prices[0]->price."€"."</a>";
                    echo "<br>";
                }
            }
            
        ?>
    </body>
</html>