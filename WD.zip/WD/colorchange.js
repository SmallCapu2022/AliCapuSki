function changecolor() {
    var element = document.getElementById("googleLink");
    element.style.color = "blue";
    console.log("mon log");
}