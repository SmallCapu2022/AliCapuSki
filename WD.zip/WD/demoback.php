<?php
header('Content-Type:application/json');
 
$server="localhost";
$username="root";
$password="";
$database="wd";
$post=json_decode(file_get_contents('php://input'), true);
 
$searchTerm = $post["searchTerm"];
if(!isset($searchTerm)|| empty($searchTerm)){
    http_response_code(400);
    die();
}
 
$conn = new mysqli($server,$username,$password,$database);
if($conn->connect_error){
    die("connection BDD echouée");
}
 
$sql="SELECT name from names WHERE name LIKE '%".$searchTerm."%'";
$result=$conn->query($sql);

$array = array();
while($row = $result->fetch_assoc()){
    $array[] = $row["name"];
}

echo json_encode($array);
 
$conn->close();
?>


