<html>
	<head>
		<title><?php echo 'Bonjour'.$_GET["name"]; ?></title>
</head>
<body>
	test page php
<?php
// mon code php
echo '<p>mon code print</p>';
for($i = 0; $i <10; $i++) {
	echo $i;
}
if($_GET ["name"] == "alicia") {
?>
<h2>partie 2</h2>
<?php
for($i = 0; $i <10; $i++){
	echo $i;
}
}
?>
</body>
</html>