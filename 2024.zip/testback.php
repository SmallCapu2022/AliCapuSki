
<html>
    <head>
    </head>
    <body>
    <?php

/*
$url = "demoback.php";
// Création d'un flux
$opts = array(
  'http'=>array(
  'method'=>"POST",
  'header'=>"Content-Type:application/json",
  'content' => '{"searchTerm":"e"}'
  )
);

$context = stream_context_create($opts);

$file = file_get_contents($url, false, $context);
*/

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'localhost/2024/demoback.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{ "searchTerm": "e" }',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);

$json = json_decode($response);

var_dump($response);

?>
    </body>
</html>