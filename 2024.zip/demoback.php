<?php 
header('Content-Type:application/json');
/*
// on recupere le httpbody de la requete (raw dans postman)
$post = json_decode(file_get_contents('php://input'), true);

// on modifie notre objet
$post["modifier"] = 2;
$post["id_shop"] = 3;

// on le retourne
echo json_encode($post);
*/

$server = "localhost";
$username = "root";
$password = "";
$databaseName = "2024_back";

$post = json_decode(file_get_contents('php://input'), true);
$searchTerm = $post["searchTerm"];
if(!isset($searchTerm) || empty($searchTerm)) {
    http_response_code(400);
    die();
}

// Connexion a la base de données
$conn = new mysqli($server, $username, $password, $databaseName);

// Check connection
if($conn->connect_error) {
    die("connection BDD échouée");
}

// requete SQL
$sql = "SELECT name from names WHERE name LIKE '%".$searchTerm."%'";
$result = $conn->query($sql);

//echo json_encode($result->fetch_all());

// Parcours les resultats
$array = array();
while($row = $result->fetch_assoc()) {
    $array[] = $row["name"];
}
echo json_encode($array); 
// ferme access BDD
$conn->close();


?>