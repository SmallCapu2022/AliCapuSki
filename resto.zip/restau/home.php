<html>
<head>
    <link rel="stylesheet" href="userstyle.css"/>   
    <link rel="icon" href="favicon.ico"/>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="logo.png"/>
        </diV>
    <?php
    $url = "http://test.api.catering.bluecodegames.com/menu";

    $postdata = json_encode(
        array(
            'id_shop' => '1'
        )
    );
    // Création d'un flux
    $opts = array(
        'http'=>array(
            'method'=>"POST",
            'header'=>"Content-Type:application/json",
            'content' => $postdata
        )
    );
  
    $context = stream_context_create($opts);
  
    // Accès à un fichier HTTP avec les entêtes HTTP indiqués ci-dessus
    $file = file_get_contents($url, false, $context);
    $json = json_decode($file);
    foreach($json->data as $subarray) {
        ?>
        <div class="category">
            <span class="title"><?php echo $subarray->name_fr; ?></span>
            <?php 
            foreach($subarray->items as $item) {
                $param = urlencode(json_encode($item));
                ?>
                <div class="plat">
                    <a href="plat2.php?item=<?php echo $param; ?>"><?php echo $item->name_fr; ?></a>
                </div>
                <?php
            }
            ?>
        </div>
        <?php
    }
    ?>
    </div>
</body>
</html>