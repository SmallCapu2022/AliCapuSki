<?php
if(isset($_POST["fname"])) {
    echo $_POST["fname"];
}
?>
<html>
    <body>
        <form method="post">
            <input type="text" name="fname">
            <button>send</button>
        </form>
    </body>
</html>