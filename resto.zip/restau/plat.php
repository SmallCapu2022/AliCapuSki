<html>
<head>
    <link rel="stylesheet" href="userstyle.css"/>
    <link rel="stylesheet" href="slideshow.css"/>
</head>
<body>
    <?php
    // Slideshow
        $item = json_decode($_GET["item"]);
        echo '<div class="slideshow-container">';
        $count = 1;
        foreach($item->images as $image) { 
        echo '
        <div class="mySlides fade">
        <div class="numbertext">'.$count.' / '.count($item->images).'</div>
        <img src="'.$image.'" class="cover" onerror="this.onerror=null; this.src=\'404.jpg\'">
        </div>';
        $count += 1;
        }
        echo '</div>';
    ?>
    <div style="text-align:center">
    <?php
    // DOTS
    foreach($item->images as $image) {
echo '<span class="dot"></span>';
    }
    ?>
  </div>
  <div class="title">
    <?php
    // Title
    echo '<h1>'.$item->name_fr.'</h1>';
    ?>
  </div>
  <div>
    <?php
    // Ingredients
    foreach($item->ingredients as $ingredient) {
      echo'<span class="ingredient"/>';
      echo $ingredient->name_fr;
      echo '</span>';
    }
    ?>
  </div>
  <div class="pricecontainer">
    <?php
    // Price
    foreach($item->prices as $price) {
      echo '<div class="price">';
      echo'<span class="priceTitle"/>';
      echo '<h3>'.$price->size.'</h3>';
      echo '</span>';
      echo'<span class="pricePrice"/>';
      echo $price->price."€";
      echo '<img src="shop.png" class="shop" width="50px" height="50px"/>';
      echo '</span>';
      echo '</div>';
    }
    ?>
  </div>
  <script src="slideshow.js"></script>
</body>
</html>