function afficherInscription() {
    window.location.href = "inscription.html"; // Redirection vers la page d'inscription
}
