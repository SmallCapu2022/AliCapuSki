-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 30 avr. 2024 à 10:17
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ski`
--

-- --------------------------------------------------------

--
-- Structure de la table `piste`
--

CREATE TABLE `piste` (
  `ppiste` int(11) NOT NULL,
  `nom` text NOT NULL,
  `couleur` text NOT NULL,
  `etat` text NOT NULL,
  `commentaire` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `piste`
--

INSERT INTO `piste` (`ppiste`, `nom`, `couleur`, `etat`, `commentaire`) VALUES
(1, 'La Monthery', 'Verte', 'ouvert', NULL),
(2, 'Le Forest', 'Verte', 'ouvert', NULL),
(3, 'Bouticari Vert', 'Verte', 'ouvert', NULL),
(4, 'Jonction Basse', 'Verte', 'ouvert', NULL),
(5, 'Les Casses', 'Bleue', 'ouvert', NULL),
(6, 'Les Neiges', 'Bleue', 'fermé', NULL),
(7, 'Les Atodos', 'Bleue', 'ouvert', NULL),
(8, 'Les Jockeys', 'Rouge', 'ouvert', NULL),
(9, 'Le Chamois', 'Rouge', 'ouvert', NULL),
(10, 'L’Écureuil', 'Rouge', 'ouvert', NULL),
(11, 'Le Tétras', 'Noire', 'ouvert', NULL),
(12, 'Le Lièvre', 'Noire', 'ouvert', NULL),
(13, 'As du Chamois', 'Bleue', 'ouvert', NULL),
(14, 'Les Lampions', 'Bleue', 'ouvert', NULL),
(15, 'Le Gourq', 'Bleue', 'ouvert', NULL),
(16, 'Les Douzeaux', 'Bleue', 'ouvert', NULL),
(17, 'L’Arbre', 'Bleue', 'ouvert', NULL),
(18, 'Bouticari Bleu', 'Bleue', 'ouvert', NULL),
(19, 'L’Inglin', 'Bleue', 'ouvert', NULL),
(20, 'Le Grand Serre', 'Bleue', 'ouvert', NULL),
(21, 'La Gérabio', 'Bleue', 'ouvert', NULL),
(22, 'La Mandarine', 'Rouge', 'ouvert', NULL),
(23, 'Pré Méan', 'Rouge', 'ouvert', NULL),
(24, 'L’Ousselat', 'Rouge', 'ouvert', NULL),
(25, 'Barrigart', 'Rouge', 'ouvert', NULL),
(37, 'La Rouge Bouticari', 'Rouge', 'ouvert', NULL),
(38, 'Les Sagnières', 'Rouge', 'ouvert', NULL),
(39, 'La Draye', 'Rouge', 'ouvert', NULL),
(51, 'Le Gourq', 'Bleue', 'ouvert', NULL),
(52, 'Les Douzeaux', 'Bleue', 'ouvert', NULL),
(53, 'L’Arbre', 'Bleue', 'ouvert', NULL),
(54, 'Bouticari Bleu', 'Bleue', 'ouvert', NULL),
(55, 'L’Inglin', 'Bleue', 'ouvert', NULL),
(56, 'Le Grand Serre', 'Bleue', 'ouvert', NULL),
(57, 'La Gérabio', 'Bleue', 'ouvert', NULL),
(58, 'Les Jockeys', 'Rouge', 'ouvert', NULL),
(59, 'Le Chamois', 'Rouge', 'ouvert', NULL),
(60, 'L’Écureuil', 'Rouge', 'ouvert', NULL),
(61, 'La Mandarine', 'Rouge', 'ouvert', NULL),
(62, 'Pré Méan', 'Rouge', 'ouvert', NULL),
(63, 'L’Ousselat', 'Rouge', 'ouvert', NULL),
(64, 'Barrigart', 'Rouge', 'ouvert', NULL),
(65, 'La Rouge Bouticari', 'Rouge', 'ouvert', NULL),
(66, 'Les Sagnières', 'Rouge', 'ouvert', NULL),
(67, 'La Draye', 'Rouge', 'ouvert', NULL),
(68, 'Le Tétras', 'Noire', 'ouvert', NULL),
(69, 'Le Lièvre', 'Noire', 'ouvert', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `remontee`
--

CREATE TABLE `remontee` (
  `premontee` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `etat` varchar(50) DEFAULT NULL,
  `piste_ppiste` int(11) DEFAULT NULL,
  `commentaire` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `remontee`
--

INSERT INTO `remontee` (`premontee`, `nom`, `etat`, `piste_ppiste`, `commentaire`) VALUES
(1, 'La Troïka', 'fermé', NULL, NULL),
(2, 'Les Torres', 'ouvert', NULL, NULL),
(3, 'Les Amoureux', 'ouvert', NULL, NULL),
(4, 'La Burge', 'ouvert', NULL, NULL),
(5, 'Le Moulin', 'ouvert', NULL, NULL),
(6, 'Le Beauregard', 'ouvert', NULL, NULL),
(7, 'Ste Marie Madeleine', 'ouvert', NULL, NULL),
(8, 'Les Cassettes', 'ouvert', NULL, NULL),
(9, 'Le Grand Serre', 'ouvert', NULL, NULL),
(10, 'Bouticari', 'ouvert', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `motdepasse` varchar(255) NOT NULL,
  `commentaire` text NOT NULL,
  `piste_id` int(11) DEFAULT NULL,
  `remontee_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `identifiant`, `motdepasse`, `commentaire`, `piste_id`, `remontee_id`) VALUES
(1, '', '', '', '', NULL, NULL),
(4, 'Capu', 'TinyCapu', 'piloupilou', '', NULL, NULL),
(7, 'njn', 'bjbj', 'bjui', '', NULL, NULL),
(8, 'capu', 'deba', '2024', 'Les remontées sont bondées !!', NULL, NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `piste`
--
ALTER TABLE `piste`
  ADD PRIMARY KEY (`ppiste`);

--
-- Index pour la table `remontee`
--
ALTER TABLE `remontee`
  ADD PRIMARY KEY (`premontee`),
  ADD KEY `piste_ppiste` (`piste_ppiste`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `identifiant` (`identifiant`),
  ADD KEY `piste_id` (`piste_id`),
  ADD KEY `remontee_id` (`remontee_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `piste`
--
ALTER TABLE `piste`
  MODIFY `ppiste` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT pour la table `remontee`
--
ALTER TABLE `remontee`
  MODIFY `premontee` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `remontee`
--
ALTER TABLE `remontee`
  ADD CONSTRAINT `remontee_ibfk_1` FOREIGN KEY (`piste_ppiste`) REFERENCES `piste` (`ppiste`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`piste_id`) REFERENCES `piste` (`ppiste`),
  ADD CONSTRAINT `utilisateur_ibfk_2` FOREIGN KEY (`remontee_id`) REFERENCES `remontee` (`premontee`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
