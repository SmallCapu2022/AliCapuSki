<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" href="img/favicon.png">
  <title>Waze Queyras</title>
  <!-- Liens vers les bibliothèques Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Styles personnalisés -->
  <link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>

<!-- Barre de navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Waze Queyras</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Accueil <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">À propos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="utilisateur.html">Connexion</a>
      </li>
    </ul>
  </div>
</nav>

<!-- Carrousel -->
<div id="carouselExampleControls" class="carousel slide mx-auto" style="max-width: 800px; " data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/1.jpg" class="d-block w-100" alt="Image 1">
    </div>
    <div class="carousel-item">
      <img src="img/2.jpg" class="d-block w-100" alt="Image 2">
    </div>
    <div class="carousel-item">
      <img src="img/3.jpg" class="d-block w-100" alt="Image 3">
    </div>
    <div class="carousel-item">
      <img src="img/4.jpg" class="d-block w-100" alt="Image 4">
    </div>
    <div class="carousel-item">
      <img src="img/5.jpg" class="d-block w-100" alt="Image 5">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Précédent</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Suivant</span>
  </a>
</div>

<!-- Affichage des commentaires -->
<div class="container mt-5">
  <h2>Commentaires des utilisateurs</h2>
  <div class="row">
  <?php
// Inclure le fichier de connexion à la base de données
include_once "connexion.php";

// Sélectionner tous les commentaires des utilisateurs
$sql = "SELECT commentaire, identifiant FROM utilisateur WHERE commentaire !=' '";
$result = $conn->query($sql);

// Vérifier s'il y a des commentaires à afficher
if ($result->num_rows > 0) {
    // Afficher les données des pistes dans un tableau HTML
    echo "<table class='table'>
            <thead>
                <tr>
                    <th>Commentaire</th>
                    <th>Utilisateur</th>
                </tr>
            </thead>
            <tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['commentaire'] . "</td>";
        echo "<td>" . $row['identifiant'] . "</td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
    
} else {
    echo "Aucun commentaire trouvé.";
}

// Fermer la connexion à la base de données
$conn->close();
?>

  </div>
</div>

<!-- Liens vers les bibliothèques Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<div class="footer">
  <p> Copyright&copy; 2024 Alicia & Capucine </p>
</div>
</body>
</html>
