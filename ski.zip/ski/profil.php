<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['identifiant'])) {
    // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    header("location: utilisateur.html");
    exit; // Arrêter l'exécution du script après la redirection
}

// Vérifier si le formulaire a été soumis via la méthode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Inclure le fichier de connexion à la base de données
    include_once "connexion.php";

    // Récupérer le commentaire soumis via le formulaire
    $commentaire = $_POST['commentaire'];

    // Récupérer l'identifiant de l'utilisateur à partir de la session
    $userId = $_SESSION['identifiant']['identifiant'];

    // Préparer la requête SQL pour insérer le commentaire de l'utilisateur dans la base de données
    $sql = "UPDATE utilisateur SET commentaire='$commentaire' WHERE identifiant='$userId'";

    // Exécuter la requête SQL
    if ($conn->query($sql) === TRUE) {
        // Rediriger l'utilisateur vers la page d'accueil ou toute autre page appropriée
        header("location: accueil.php");
        exit; // Arrêter l'exécution du script après la redirection
    } else {
        echo "Erreur lors de l'ajout du commentaire : " . $conn->error;
    }

    // Fermer la connexion à la base de données
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre application</title>
    <link rel="icon" type="image/png" href="img/favicon.png">
    <!-- Liens vers les bibliothèques Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Styles personnalisés -->
    <link rel="stylesheet" type="text/css" href="css/style.css"/>

</head>
<body>

<!-- Barre de navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Waze Queyras</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="accueil.php">MENU</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo isset($_SESSION['identifiant']) ? 'profil.php' : 'utilisateur.html'; ?>">Mon profil</a>
            </li>
            <li class="nav-item">
                <a href="logout.php" class="btn btn-secondary custom-btn btn-lg active" role="button" aria-pressed="true">Log Out</a>
            </li>
        </ul>
        <!-- Afficher le nom de l'utilisateur si connecté -->
        <?php
        if (isset($_SESSION['identifiant'])) {
            $username = $_SESSION['identifiant']['nom']; // Remplacez 'nom' par le champ approprié de votre table utilisateur
            echo '<span class="navbar-text">Connecté en tant que ' . $username . '</span>';
        }
        ?>
    </div>
</nav>
<div class="container mt-5">
    <h1>Profil de l'utilisateur</h1>
    <?php
        if (isset($_SESSION['identifiant'])) {
            $username = $_SESSION['identifiant']['nom'];
            $id = $_SESSION['identifiant']['identifiant']; // Remplacez 'nom' par le champ approprié de votre table utilisateur
            echo '<span class="navbar-text">NOM :' . $username . '</span>';
            echo"<br>";
            echo '<span class="navbar-text">IDENTIFIANT :' . $id . '</span>';
        }
        ?>
    <p>Entrez un commentaire :</p>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="commentaire">Commentaire :</label>
        <textarea id="commentaire" name="commentaire" rows="4" cols="50"></textarea><br>
        <input type="submit" value="Ajouter un commentaire">
    </form>
    </div>
</body>
</html>
